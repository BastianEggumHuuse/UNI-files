public class legemiddel {
    public final String navn;
    public int pris;
    public final double mengdeVirkestoff;
    public final int ID;

    public static void main(String navn,int pris, double mengdeVirkestoff) {

        this.navn = navn;
        this.pris = pris;
        this.mengdeVirkestoff = mengdeVirkestoff;

    }


}