public class narkotisk {
    public final String navn;
    public int pris;
    public final double mengdeVirkestoff;
    public final int styrke;
    public final int ID;

    public static void main(String navn,int pris, double mengdeVirkestoff,int styrke) {

        this.navn = navn;
        this.pris = pris;
        this.mengdeVirkestoff = mengdeVirkestoff;
        this.styrke = styrke;

    }
}