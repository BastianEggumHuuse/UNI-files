# Fellesøvelser 

Hei! 

Her vil vi legge ut ressurser fra fellesøvelsene i IN1010 våren 2025. Ta kontakt med plenumsansvarlig på bralreka@uio.no hvis du har spørsmål, innspill eller kommentarer!
