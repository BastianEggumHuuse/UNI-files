import java.util.*;

public abstract class Pattedyr extends Dyr {

    public final static String KLASSE = "Mammalia";

    public Pattedyr(HashSet<String> kjennetegn) {
	super(kjennetegn);
    }
}
