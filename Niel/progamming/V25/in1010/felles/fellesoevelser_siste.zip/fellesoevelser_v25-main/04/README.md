# Uke 04 - Arv 3: Grensesnitt

Velkommen til fjerde fellesøvelse med Bushra og venner!

På mandag skal vi bygge ferdig vår modell av [Artsdatabanken](https://artsdatabanken.no). Hvis du gikk glipp av forrige fellesøvelse, må du gjerne ta en titt på forrige ukes ressurser. Vi går kort gjennom programmet vi har skrevet så langt før vi går i gang med ukas tema. Vi skal skrive noen nye klasser og implementere ulike *grensesnitt* – både egendefinerte og fra Javas standardbibliotek.

Vi sees!
